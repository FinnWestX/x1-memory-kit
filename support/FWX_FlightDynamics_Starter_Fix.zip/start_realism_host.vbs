' FWX Flight Dynamics starter with restart watchdog (customer fix 2026-10-07)
Option Explicit

Const HOST_EXE      = "fwx_flightmodel_host.exe"
Const CHECK_MS      = 120000
Const MAX_RESTARTS  = 30

Dim sh, fso, here, wmi, restarts

Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
here = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = here

' Stop an old instance, then start the program hidden.
sh.Run "cmd /c taskkill /F /IM " & HOST_EXE & " >nul 2>&1", 0, True
WScript.Sleep 500
StartHost

' Watchdog: restart the program while the simulator is running.
On Error Resume Next
Set wmi = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\cimv2")
If Err.Number <> 0 Then WScript.Quit 0
On Error GoTo 0

' Only one watchdog at a time.
If CountWatchers() > 1 Then WScript.Quit 0

restarts = 0
Do
    WScript.Sleep CHECK_MS
    If Not SimRunning() Then Exit Do
    If Not ProcessRunning(HOST_EXE) Then
        If restarts >= MAX_RESTARTS Then Exit Do
        StartHost
        restarts = restarts + 1
    End If
Loop
WScript.Quit 0

Sub StartHost()
    sh.Run """" & here & "\" & HOST_EXE & """", 0, False
End Sub

Function ProcessRunning(exeName)
    Dim col
    ProcessRunning = False
    On Error Resume Next
    Set col = wmi.ExecQuery("SELECT ProcessId FROM Win32_Process WHERE Name='" & exeName & "'")
    If Err.Number = 0 Then
        If col.Count > 0 Then ProcessRunning = True
    Else
        ProcessRunning = True
    End If
    On Error GoTo 0
End Function

Function SimRunning()
    SimRunning = ProcessRunning("FlightSimulator2024.exe") Or ProcessRunning("FlightSimulator.exe")
End Function

Function CountWatchers()
    Dim col, p, cmd, myName
    CountWatchers = 0
    myName = LCase(fso.GetFileName(WScript.ScriptFullName))
    On Error Resume Next
    Set col = wmi.ExecQuery("SELECT CommandLine FROM Win32_Process WHERE Name='wscript.exe' OR Name='cscript.exe'")
    If Err.Number <> 0 Then
        CountWatchers = 1
        On Error GoTo 0
        Exit Function
    End If
    For Each p In col
        cmd = ""
        cmd = LCase(p.CommandLine & "")
        If InStr(cmd, myName) > 0 Then CountWatchers = CountWatchers + 1
    Next
    On Error GoTo 0
End Function
