FWX Aviation Press Kit - June 2026
===================================

Contact: Finn.West@gmx.net
Online press page: https://finnwestx1.com/press.html

Contents
--------

Logos
  fwx-logo.svg
  fwx-logo-256.png
  fwx-logo-512.png
  fwx-logo-1024.png
  fwx-logo-2048.png
  fwx-logo-512-white.png
  fwx-logo-512-black.png
  fwx-favicon.ico

Screenshots
  product-screenshot-1.jpg
  product-screenshot-2.jpg
  product-screenshot-3.jpg
  gui-haptic.png
  shadow-mod-1.jpg
  shadow-mod-2.jpg
  shadow-mod-3.jpg
  shadow-mod-4.jpg

Demo videos
  rotor-shadow-demo.mp4 (local file)
  Inside Sound:        https://youtu.be/JlRNiW8-uD4
  External Sound:      https://youtu.be/J0LsG0I_2nk
  Inside Highlights:   https://youtu.be/ZVN1D-Lr_eQ
  Rotor Shadow Demo:   https://youtu.be/I_a2cM_WxMw

PDF documents
  press-release-fwx-aviation-2026-06.pdf
  fact-sheet-fwx-aviation.pdf
  brand-guidelines-fwx-aviation.pdf

Usage
-----
All assets in this kit may be used in editorial and review coverage of
FWX Aviation products. For commercial or unrelated use, please request
permission first via Finn.West@gmx.net.

Trademarks: EC135 is a trademark of Airbus Helicopters. Microsoft Flight
Simulator 2024 is a trademark of Microsoft Corporation. ButtKicker is a
trademark of The Guitammer Company. FinnWest Aviation is not affiliated
with any of these companies.
